const firebaseConfig = {
  apiKey: "AIzaSyBLglzupI41PY6W7VJ5c_-EQ_vbbVDBbf0",
  authDomain: "fynx-f09d8.firebaseapp.com",
  projectId: "fynx-f09d8",
  storageBucket: "fynx-f09d8.firebasestorage.app",
  messagingSenderId: "184364852664",
  appId: "1:184364852664:android:3c67cf6da748f0e8291b4d"
};

let db;
// Initialize Firebase only if the SDK is loaded
if (typeof firebase !== 'undefined') {
  try {
    firebase.initializeApp(firebaseConfig);
    db = firebase.firestore();
    console.log("Firebase initialized successfully.");
  } catch (e) {
    console.error("Firebase initialization failed:", e);
  }
} else {
  console.warn("Firebase SDK not detected. Lead capture will be disabled.");
}

document.addEventListener('DOMContentLoaded', () => {
  // Animaciones de scroll
  const faders = document.querySelectorAll('.fade-in');
  
  // Fallback: Si después de 1.5s no se han mostrado, forzar visibilidad
  setTimeout(() => {
    faders.forEach(f => f.classList.add('visible'));
  }, 1500);

  const appearOptions = { threshold: 0.15, rootMargin: "0px 0px -50px 0px" };

  const appearOnScroll = new IntersectionObserver(function(entries, observer) {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    });
  }, appearOptions);

  faders.forEach(fader => appearOnScroll.observe(fader));

  // Lógica de Captura de Leads
  const form = document.getElementById('waitlist-form');
  const emailInput = document.getElementById('waitlist-email');
  const btn = document.getElementById('waitlist-btn');
  const msg = document.getElementById('waitlist-message');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      if (!email) return;

      // Verificar si Firebase se inicializó correctamente
      if (!db) {
        console.error("No se pudo conectar con la base de datos.");
        msg.textContent = "Error de conexión. Por favor, intenta más tarde.";
        msg.className = "waitlist-message error";
        return;
      }

      btn.disabled = true;
      btn.textContent = "Guardando...";
      msg.textContent = "";
      msg.className = "waitlist-message";

      try {
        await db.collection("waitlist_leads").add({
          email: email,
          timestamp: new Date().toISOString()
        });
        
        emailInput.value = "";
        msg.textContent = "¡Gracias por unirte! Te notificaremos pronto.";
        msg.classList.add("success");
      } catch (error) {
        console.error("Error saving lead: ", error);
        msg.textContent = "Hubo un error al guardar tu correo. Intenta de nuevo.";
        msg.classList.add("error");
      } finally {
        btn.disabled = false;
        btn.textContent = "Unirme a la lista VIP";
      }
    });
  }
});
